import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Copy, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { ProfileTab } from "@/types/profile";
import { useWallet } from "@/hooks/useWallet";
import { useLaunchpad } from "@/lib/launchpadClient";
import type { CampaignSummary } from "@/lib/launchpadClient";
import { BrowserProvider, Contract, ethers } from "ethers";

type TokenBalanceRow = {
  campaignAddress: string;
  tokenAddress: string;
  image: string;
  name: string;
  ticker: string;
  balanceRaw: bigint;
  balanceFormatted: string;
};

const ERC20_ABI_MIN = [
  {
    type: "function",
    name: "balanceOf",
    stateMutability: "view",
    inputs: [{ name: "account", type: "address" }],
    outputs: [{ name: "balance", type: "uint256" }],
  },
  {
    type: "function",
    name: "decimals",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "decimals", type: "uint8" }],
  },
  {
    type: "function",
    name: "symbol",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "symbol", type: "string" }],
  },
] as const;

function getExplorerBase(chainId?: number): string {
  // BSC
  if (chainId === 97) return "https://testnet.bscscan.com";
  if (chainId === 56) return "https://bscscan.com";

  // Fallback (keeps link valid-ish)
  return "https://bscscan.com";
}

function shorten(addr?: string | null) {
  if (!addr) return "";
  if (addr.length <= 10) return addr;
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

function pickTokenAddressFromSummary(s: CampaignSummary): string | null {
  const anyCampaign: any = s?.campaign as any;
  // Try common fields (adjust once you confirm your schema)
  return (
    anyCampaign?.token ||
    anyCampaign?.tokenAddress ||
    anyCampaign?.tokenContract ||
    anyCampaign?.tokenAddr ||
    null
  );
}

const Profile = () => {
  const navigate = useNavigate();
  const wallet = useWallet();
  const { fetchCampaigns, fetchCampaignSummary } = useLaunchpad();

  const anyWallet: any = wallet as any;

  // Prefer an explicit isConnected flag if your hook provides it.
  const isConnected: boolean = Boolean(
    anyWallet?.isConnected ?? anyWallet?.connected ?? wallet.account
  );

  const account: string | null = isConnected ? (wallet.account ?? null) : null;
  const chainId: number | undefined = anyWallet?.chainId ?? anyWallet?.network?.chainId;

  const [activeTab, setActiveTab] = useState<ProfileTab>("balances");

  const [created, setCreated] = useState<
    Array<{
      id: number;
      image: string;
      name: string;
      ticker: string;
      campaignAddress: string;
      marketCap: string;
      timeAgo: string;
      buyersCount?: number;
    }>
  >([]);

  const [nativeBalance, setNativeBalance] = useState<string>("");
  const [tokenBalances, setTokenBalances] = useState<TokenBalanceRow[]>([]);
  const [loadingBalances, setLoadingBalances] = useState(false);

  const walletAddressShort = useMemo(() => shorten(account), [account]);
  const walletAddressFull = account ?? "Not connected";

  const explorerUrl = useMemo(() => {
    if (!account) return "#";
    const base = getExplorerBase(chainId);
    return `${base}/address/${account}`;
  }, [account, chainId]);

  const formatTimeAgo = (createdAt?: number): string => {
    if (!createdAt) return "";
    const now = Math.floor(Date.now() / 1000);
    const diff = Math.max(0, now - createdAt);
    if (diff < 60) return "now";
    const mins = Math.floor(diff / 60);
    if (mins < 60) return `${mins}m`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}d`;
    const weeks = Math.floor(days / 7);
    return `${weeks}w`;
  };

  const handleCopyAddress = () => {
    if (!account) return;
    navigator.clipboard.writeText(account);
    toast.success("Address copied!");
  };

  const handleConnect = async () => {
    // Try common hook patterns
    if (typeof anyWallet?.connect === "function") return anyWallet.connect();
    if (typeof anyWallet?.openConnectModal === "function") return anyWallet.openConnectModal();

    toast.message("Use the Connect Wallet button in the header to connect.");
  };

  const handleEdit = () => {
    // MVP placeholder: later open a dialog for display name, bio, notification toggles, etc.
    toast.message("Edit profile: coming soon (name, bio, notification settings).");
  };

  // Load created campaigns (creator view)
  useEffect(() => {
    let cancelled = false;

    const loadCreated = async () => {
      try {
        if (!account) {
          setCreated([]);
          return;
        }

        const campaigns = (await fetchCampaigns()) ?? [];
        const mine = campaigns.filter(
          (c) => (c.creator ?? "").toLowerCase() === account.toLowerCase()
        );

        const results = await Promise.allSettled(mine.map((c) => fetchCampaignSummary(c)));

        if (cancelled) return;

        const next = results
          .filter(
            (r): r is PromiseFulfilledResult<CampaignSummary> => r.status === "fulfilled"
          )
          .map((r, idx) => {
            const s = r.value;
            return {
              id: typeof s.campaign.id === "number" ? s.campaign.id : idx + 1,
              image: s.campaign.logoURI || "/placeholder.svg",
              name: s.campaign.name,
              ticker: s.campaign.symbol,
              campaignAddress: s.campaign.campaign,
              marketCap: s.stats.marketCap,
              timeAgo: (s.campaign as any).timeAgo || formatTimeAgo(s.campaign.createdAt),
              buyersCount: (s.stats as any)?.buyersCount ?? undefined,
            };
          });

        setCreated(next);
      } catch (e) {
        console.error("[Profile] Failed to load created campaigns", e);
        if (!cancelled) setCreated([]);
      }
    };

    loadCreated();
    return () => {
      cancelled = true;
    };
  }, [account, fetchCampaigns, fetchCampaignSummary]);

  // Load balances (native + launchpad token balances)
  useEffect(() => {
    let cancelled = false;

    const loadBalances = async () => {
      try {
        if (!account) {
          setNativeBalance("");
          setTokenBalances([]);
          return;
        }

				// IMPORTANT:
				// useWallet() exposes an Ethers BrowserProvider, which is NOT an EIP-1193 provider.
				// viem's `custom()` transport expects an EIP-1193 provider (with `.request`).
				// To avoid runtime failures ("reading 'bind'"), we use Ethers for reads here.
				const injected = (window as any)?.ethereum;
				const readProvider: BrowserProvider | null = anyWallet?.provider
					? (anyWallet.provider as BrowserProvider)
					: injected
						? new BrowserProvider(
							// Prefer MetaMask if multiple providers are injected.
							injected.providers?.find?.((p: any) => p.isMetaMask) || injected
						)
						: null;

				if (!readProvider) {
					setNativeBalance("");
					setTokenBalances([]);
					return;
				}

        setLoadingBalances(true);

        // Native (BNB) balance
				const bal = await readProvider.getBalance(account);
				const bnb = Number(ethers.formatEther(bal)).toFixed(4);
        if (!cancelled) setNativeBalance(`${bnb} BNB`);

        // Launchpad token balances:
        // We scan campaigns and check balanceOf(account) for each associated token contract.
        const campaigns = (await fetchCampaigns()) ?? [];
        const summaries = await Promise.allSettled(
          campaigns.map((c) => fetchCampaignSummary(c))
        );

        const fulfilled = summaries
          .filter(
            (r): r is PromiseFulfilledResult<CampaignSummary> => r.status === "fulfilled"
          )
          .map((r) => r.value);

        // Build balance rows
        const rows: TokenBalanceRow[] = [];

				for (const s of fulfilled) {
          const tokenAddr = pickTokenAddressFromSummary(s);
          if (!tokenAddr) continue;

          try {
						const erc20 = new Contract(tokenAddr, ERC20_ABI_MIN as any, readProvider);
						const [rawBal, decimals, symbolMaybe] = await Promise.all([
							erc20.balanceOf(account) as Promise<bigint>,
							erc20.decimals() as Promise<number>,
							// symbol() can revert on weird tokens; tolerate failures
							Promise.resolve(erc20.symbol() as Promise<string>).catch(() => null),
						]);

            if (rawBal <= 0n) continue;

						const formatted = ethers.formatUnits(rawBal, decimals);
            rows.push({
              campaignAddress: s.campaign.campaign,
              tokenAddress: tokenAddr,
              image: s.campaign.logoURI || "/placeholder.svg",
              name: s.campaign.name,
              ticker: s.campaign.symbol || symbolMaybe || "",
              balanceRaw: rawBal,
              balanceFormatted: formatted,
            });
          } catch {
            // ignore token read failures per token
            continue;
          }
        }

        if (!cancelled) {
          // Sort biggest balances first (by raw units; acceptable for MVP)
          setTokenBalances(rows.sort((a, b) => (a.balanceRaw > b.balanceRaw ? -1 : 1)));
        }
      } catch (e) {
        console.error("[Profile] Failed to load balances", e);
        if (!cancelled) {
          setNativeBalance("");
          setTokenBalances([]);
        }
      } finally {
        if (!cancelled) setLoadingBalances(false);
      }
    };

    loadBalances();
    return () => {
      cancelled = true;
    };
  }, [account, fetchCampaigns, fetchCampaignSummary]);

  // Followers/Following numbers (MVP proxies)
  const followingCount = 0; // later: number of followed creators/coins (watchlist)
  const followersCount = useMemo(() => {
    // MVP proxy:
    // If you created coins, treat total buyersCount as "followers" (better label later: "Investors").
    const sum = created.reduce((acc, c) => acc + (c.buyersCount ?? 0), 0);
    return sum;
  }, [created]);

  return (
     <div className="h-full w-full relative">
      {/* Disconnect Overlay */}
      {!isConnected && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-background/60 backdrop-blur-sm">
          <div className="bg-card/40 border border-border rounded-2xl p-8 text-center max-w-md w-[92%]">
            <div className="font-retro text-foreground text-xl mb-2">Connect your wallet</div>
            <div className="font-retro text-muted-foreground text-sm mb-6">
              The Profile page is only available when you’re connected.
            </div>
            <Button
              onClick={handleConnect}
              className="bg-accent hover:bg-accent/80 text-accent-foreground font-retro w-full"
            >
              Connect Wallet
            </Button>
          </div>
        </div>
      )}

      <div
        className={`h-full p-4 md:p-6 overflow-y-auto ${
          !isConnected ? "blur-md pointer-events-none select-none" : ""
        }`}
      >
        {/* Profile Header */}
        <div className="bg-card/30 backdrop-blur-md rounded-2xl p-4 md:p-6 border border-border mb-4">
          <div className="flex flex-col md:flex-row items-start justify-between mb-6 gap-4">
            <div className="flex flex-col sm:flex-row gap-4 md:gap-6 w-full md:w-auto">
              {/* Avatar */}
              <div className="w-20 h-20 md:w-28 md:h-28 rounded-full bg-accent/20 border-4 border-accent/30 overflow-hidden mx-auto sm:mx-0">
                <img
                  src="https://images.unsplash.com/photo-1621504450181-5d356f61d307?w=200&h=200&fit=crop"
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Profile Info */}
              <div className="flex-1 text-center sm:text-left">
                <h1 className="text-2xl md:text-3xl font-retro text-foreground mb-3">
                  {walletAddressShort || "Profile"}
                </h1>

                <div className="flex flex-col sm:flex-row items-center justify-center sm:justify-start gap-2 sm:gap-3 mb-4">
                  <span className="text-xs md:text-sm font-retro text-muted-foreground">
                    {walletAddressFull}
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCopyAddress}
                      className="p-1 hover:bg-muted rounded transition-colors"
                      disabled={!account}
                      title="Copy address"
                    >
                      <Copy className="h-4 w-4 text-muted-foreground" />
                    </button>

                    <a
                      href={explorerUrl}
                      target={account ? "_blank" : undefined}
                      rel="noreferrer"
                      className={`flex items-center gap-1 text-xs md:text-sm font-retro transition-colors ${
                        account
                          ? "text-accent hover:text-accent/80"
                          : "text-muted-foreground pointer-events-none"
                      }`}
                    >
                      View on explorer
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>

                {/* Stats */}
                <div className="flex justify-center sm:justify-start gap-6 md:gap-8">
                  <div className="text-center">
                    <div className="text-xl md:text-2xl font-retro text-foreground">
                      {followersCount}
                    </div>
                    <div className="text-xs font-retro text-muted-foreground">Followers</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl md:text-2xl font-retro text-foreground">
                      {followingCount}
                    </div>
                    <div className="text-xs font-retro text-muted-foreground">Following</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl md:text-2xl font-retro text-foreground">
                      {created.length}
                    </div>
                    <div className="text-xs font-retro text-muted-foreground">Created coins</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Edit Button */}
            <Button
              onClick={handleEdit}
              className="bg-muted hover:bg-muted/80 text-foreground font-retro w-full md:w-auto"
            >
              edit
            </Button>
          </div>

          {/* Tabs */}
          <div className="flex gap-3 md:gap-6 border-t border-border pt-4 md:pt-6 overflow-x-auto scrollbar-thin scrollbar-thumb-accent/50 scrollbar-track-muted">
            {[
              { id: "balances" as ProfileTab, label: "Balances", badge: null },
              { id: "coins" as ProfileTab, label: "Coins", badge: null },
              { id: "Replies" as ProfileTab, label: "Replies", badge: null },
              { id: "notifications" as ProfileTab, label: "Notifications", badge: 13 },
              { id: "followers" as ProfileTab, label: "Followers", badge: null },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative font-retro text-xs md:text-sm transition-colors whitespace-nowrap ${
                  activeTab === tab.id
                    ? "text-accent border-b-2 border-accent pb-2"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab.label}
                {tab.badge && (
                  <span className="absolute -top-2 -right-6 bg-destructive text-destructive-foreground text-[10px] font-retro px-1.5 py-0.5 rounded-full">
                    {tab.badge}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* BALANCES TAB */}
        {activeTab === "balances" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Left: Balances */}
            <div className="bg-card/30 backdrop-blur-md rounded-2xl p-4 md:p-6 border border-border">
              <h3 className="text-xs md:text-sm font-retro text-muted-foreground mb-4 md:mb-6">
                Balances
              </h3>

              {/* Native balance */}
              <div className="flex items-center justify-between p-3 md:p-4 bg-background/50 rounded-xl border border-border mb-3">
                <div className="flex items-center gap-3 md:gap-4">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-accent/20 flex items-center justify-center border border-border">
                    <span className="text-foreground text-xs font-bold">BNB</span>
                  </div>
                  <div>
                    <div className="font-retro text-foreground mb-1 text-sm md:text-base">
                      Native balance
                    </div>
                    <div className="text-xs md:text-sm font-retro text-muted-foreground">
                      {nativeBalance || (loadingBalances ? "Loading..." : "—")}
                    </div>
                  </div>
                </div>
              </div>

              {/* Launchpad token balances */}
              <div className="space-y-3 max-h-96 overflow-y-auto scrollbar-thin scrollbar-thumb-accent/50 scrollbar-track-muted">
                {loadingBalances && tokenBalances.length === 0 && (
                  <div className="font-retro text-muted-foreground text-sm">Loading token balances…</div>
                )}

                {!loadingBalances && tokenBalances.length === 0 && (
                  <div className="font-retro text-muted-foreground text-sm">
                    No launchpad token balances found for this wallet.
                  </div>
                )}

                {tokenBalances.map((t) => (
                  <div
                    key={`${t.tokenAddress}-${t.campaignAddress}`}
                    className="flex items-center justify-between p-3 md:p-4 bg-background/50 rounded-xl border border-border hover:border-accent/50 transition-colors cursor-pointer"
                    onClick={() => navigate(`/token/${t.campaignAddress.toLowerCase()}`)}
                    title="Open token page"
                  >
                    <div className="flex items-center gap-3 md:gap-4 min-w-0">
                      <img
                        src={t.image}
                        alt={t.name}
                        className="w-10 h-10 md:w-12 md:h-12 rounded-full border-2 border-border object-cover"
                      />
                      <div className="min-w-0">
                        <div className="font-retro text-foreground mb-1 text-sm md:text-base truncate">
                          {t.name}
                        </div>
                        <div className="text-xs md:text-sm font-retro text-muted-foreground">
                          {t.ticker}
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0 ml-4">
                      <div className="font-retro text-foreground text-sm md:text-base">
                        {Number(t.balanceFormatted).toLocaleString(undefined, {
                          maximumFractionDigits: 6,
                        })}
                      </div>
                      <div className="font-retro text-muted-foreground text-xs">Balance</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Created Coins */}
            <div className="bg-card/30 backdrop-blur-md rounded-2xl p-4 md:p-6 border border-border">
              <div className="flex items-center justify-between mb-4 md:mb-6">
                <h3 className="text-xs md:text-sm font-retro text-foreground">
                  created coins <span className="text-muted-foreground">({created.length})</span>
                </h3>
                <button className="text-xs md:text-sm font-retro text-accent hover:text-accent/80 transition-colors">
                  see all
                </button>
              </div>

              <div className="space-y-3 max-h-96 overflow-y-auto scrollbar-thin scrollbar-thumb-accent/50 scrollbar-track-muted">
                {created.map((coin) => (
                  <div
                    key={coin.id}
                    className="flex items-center justify-between p-3 bg-background/50 rounded-xl border border-border hover:border-accent/50 transition-colors cursor-pointer"
                    onClick={() => navigate(`/token/${coin.campaignAddress.toLowerCase()}`)}
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <img
                        src={coin.image}
                        alt={coin.name}
                        className="w-8 h-8 md:w-10 md:h-10 rounded-full border-2 border-border object-cover"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-retro text-foreground text-xs md:text-sm truncate">
                          {coin.name}
                        </div>
                        <div className="font-retro text-muted-foreground text-xs">{coin.ticker}</div>
                      </div>
                    </div>
                    <div className="text-right shrink-0 ml-4">
                      <div className="font-retro text-foreground text-xs md:text-sm">{coin.marketCap}</div>
                      <div className="font-retro text-muted-foreground text-xs">{coin.timeAgo}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* COINS TAB: Tokens you invested in */}
        {activeTab === "coins" && (
          <div className="bg-card/30 backdrop-blur-md rounded-2xl p-4 md:p-6 border border-border">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs md:text-sm font-retro text-foreground">
                tokens you invested in <span className="text-muted-foreground">({tokenBalances.length})</span>
              </h3>
            </div>

            {loadingBalances && (
              <div className="font-retro text-muted-foreground text-sm">Loading…</div>
            )}

            {!loadingBalances && tokenBalances.length === 0 && (
              <div className="font-retro text-muted-foreground text-sm">
                No invested tokens detected yet. Once you buy on a curve (or hold after DEX listing), it will show here.
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {tokenBalances.map((t) => (
                <div
                  key={`${t.tokenAddress}-${t.campaignAddress}-coins`}
                  className="p-4 bg-background/50 rounded-xl border border-border hover:border-accent/50 transition-colors cursor-pointer"
                  onClick={() => navigate(`/token/${t.campaignAddress.toLowerCase()}`)}
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={t.image}
                      alt={t.name}
                      className="w-10 h-10 rounded-full border-2 border-border object-cover"
                    />
                    <div className="min-w-0">
                      <div className="font-retro text-foreground text-sm truncate">{t.name}</div>
                      <div className="font-retro text-muted-foreground text-xs">{t.ticker}</div>
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between">
                    <div className="font-retro text-muted-foreground text-xs">Your balance</div>
                    <div className="font-retro text-foreground text-sm">
                      {Number(t.balanceFormatted).toLocaleString(undefined, { maximumFractionDigits: 6 })}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* REPLIES TAB: best-fit = Activity feed */}
        {activeTab === "replies" && (
          <div className="bg-card/30 backdrop-blur-md rounded-2xl p-8 md:p-12 border border-border text-center">
            <p className="font-retro text-muted-foreground text-sm md:text-base">
              Replies will become your <span className="text-foreground">Activity</span> feed:
              buys/sells, creations, and interactions. To power this we’ll either:
              (1) index events (recommended), or (2) fetch recent trades per campaign (heavier).
            </p>
          </div>
        )}

        {/* NOTIFICATIONS TAB */}
        {activeTab === "notifications" && (
          <div className="bg-card/30 backdrop-blur-md rounded-2xl p-8 md:p-12 border border-border text-center">
            <p className="font-retro text-muted-foreground text-sm md:text-base">
              Notifications MVP ideas:
              curve at 80/90/95%, graduation, large buy alerts, your created coin milestones,
              and “watched coins” updates. This needs either an indexer or a lightweight polling service.
            </p>
          </div>
        )}

        {/* FOLLOWERS TAB */}
        {activeTab === "followers" && (
          <div className="bg-card/30 backdrop-blur-md rounded-2xl p-8 md:p-12 border border-border text-center">
            <p className="font-retro text-muted-foreground text-sm md:text-base">
              Followers MVP direction:
              for creators, show investors/holders of your coins (requires event indexing);
              for regular users, this becomes “Creators you follow” and “Coins you watch”.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;
