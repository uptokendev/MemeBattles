import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { useLaunchpad } from "@/lib/launchpadClient";
import { useBnbUsdPrice } from "@/hooks/useBnbUsdPrice";
import { useLeagueRealtime } from "@/hooks/useLeagueRealtime";
import { CampaignCard, type CampaignCardVM } from "./CampaignCard";
import { resolveImageUri } from "@/lib/media";

export type FeedTabKey = "trending" | "new" | "ending" | "dex";

export type HomeQuery = {
  tab: FeedTabKey;
  status?: "all" | "live" | "graduated";
  mcapMinUsd?: number;
  mcapMaxUsd?: number;
  progressMinPct?: number;
  progressMaxPct?: number;
  category?: string;
  sort?:
    | "default"
    | "mcap_desc"
    | "mcap_asc"
    | "votes_desc"
    | "progress_desc"
    | "created_desc"
    | "created_asc";
  timeFilter?: "1h" | "24h" | "7d" | "all";
  search?: string;
};

type CampaignFeedItemApi = {
  chainId: number;
  campaignAddress: string;
  tokenAddress?: string | null;
  creatorAddress?: string | null;
  name?: string | null;
  symbol?: string | null;
  logoUri?: string | null;
  createdAtChain?: string | null;
  lastActivityAt?: string | null;
  graduatedAtChain?: string | null;
  isDexTrading?: boolean;
  marketcapBnb?: string | null;
  votes24h?: number;
  progressPct?: number | null;
  etaSec?: number | null;
};

type CampaignFeedResponse = {
  items: CampaignFeedItemApi[];
  nextCursor: number | null;
  pageSize: number;
  updatedAt?: string;
};

function safeUnixSeconds(ts: any): number | null {
  if (ts == null) return null;
  if (typeof ts === "number" && Number.isFinite(ts)) {
    return ts > 1e12 ? Math.floor(ts / 1000) : Math.floor(ts);
  }
  if (typeof ts === "string") {
    const asNum = Number(ts);
    if (Number.isFinite(asNum) && asNum > 0) return asNum > 1e12 ? Math.floor(asNum / 1000) : Math.floor(asNum);
    const ms = Date.parse(ts);
    if (Number.isFinite(ms)) return Math.floor(ms / 1000);
  }
  return null;
}

function formatCompactUsd(value: number): string {
  if (!Number.isFinite(value)) return "—";
  const fmt = new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: "USD",
    notation: "compact",
    maximumFractionDigits: 2,
  });
  return fmt.format(value);
}

function buildQueryString(params: Record<string, any>) {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v == null) continue;
    if (typeof v === "string" && v.trim() === "") continue;
    qs.set(k, String(v));
  }
  return qs.toString();
}

async function fetchCampaignFeed(params: Record<string, any>): Promise<CampaignFeedResponse> {
  const qs = buildQueryString(params);
  // Avoid CDN/browser caching for dynamic leaderboards (votes, trending, etc.).
  // Vercel edge caching keys on the URL, so include a changing param when callers want a refresh.
  const r = await fetch(`/api/campaigns?${qs}`, { cache: "no-store" as any });
  const j = await r.json();
  if (!r.ok) throw new Error(j?.error ?? "Failed to load campaigns");
  return j as CampaignFeedResponse;
}

export function CampaignGrid({ className, query }: { className?: string; query: HomeQuery }) {
  const { activeChainId, fetchCampaignLogoURI } = useLaunchpad();
  const [refetchNonce, setRefetchNonce] = useState(0);

const { patchByCampaign, created } = useLeagueRealtime({
  enabled: true,
  chainId: activeChainId,
  fallbackMs: 25000,
  onFallbackRefresh: () => setRefetchNonce((n) => n + 1),
});
  const { price: bnbUsd } = useBnbUsdPrice(true);

  // Debug toggle (works in production):
  //   localStorage.setItem('debug_campaign_grid', '1'); location.reload();
  //   localStorage.removeItem('debug_campaign_grid'); location.reload();
  const DEBUG =
    typeof window !== "undefined" &&
    (window.localStorage?.getItem("debug_campaign_grid") === "1" ||
      // Allow an escape hatch if you prefer a global flag.
      (window as any).__DEBUG_CAMPAIGN_GRID__ === true);

  const [items, setItems] = useState<CampaignFeedItemApi[]>([]);
  // Lightweight on-chain hydration for missing logo_uri in the DB-backed feed.
  const [logoCache, setLogoCache] = useState<Record<string, string>>({});
  const [nextCursor, setNextCursor] = useState<number | null>(0);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [lastUpdatedAt, setLastUpdatedAt] = useState<string | null>(null);

  // Insert newly-created campaigns instantly (no REST refetch) for the "New" tab.
  // Trending/etc will naturally catch up via periodic snapshot refresh.
  useEffect(() => {
    if (query.tab !== "new") return;
    if (!created?.length) return;

    setItems((prev) => {
      const seen = new Set(prev.map((x) => String(x.campaignAddress ?? "").toLowerCase()).filter(Boolean));
      const additions: CampaignFeedItemApi[] = [];

      for (const it of created) {
        const addr = String(it?.campaignAddress ?? "").toLowerCase();
        if (!addr || seen.has(addr)) continue;
        seen.add(addr);

        additions.push({
          chainId: activeChainId,
          campaignAddress: addr,
          tokenAddress: it.tokenAddress ?? null,
          creatorAddress: it.creatorAddress ?? null,
          name: it.name ?? null,
          symbol: it.symbol ?? null,
          logoUri: null,
          createdAtChain: it.createdAtChain ?? new Date().toISOString(),
          graduatedAtChain: null,
          isDexTrading: false,
          marketcapBnb: null,
          votes24h: 0,
          progressPct: 0,
          etaSec: null,
        });
      }

      if (!additions.length) return prev;
      return [...additions, ...prev].slice(0, 200);
    });
  }, [created, query.tab, activeChainId]);

  // Immediately refresh the feed after a confirmed tx (upvote/buy/sell/finalize)
  // so the card order and vote counts update without requiring a hard reload.
  useEffect(() => {
    const onRefresh = (e: any) => {
      const d = e?.detail ?? {};
      const cid = Number(d.chainId ?? NaN);
      if (Number.isFinite(cid) && cid !== activeChainId) return;
      setRefetchNonce((n) => n + 1);
    };
    window.addEventListener("memebattles:upvoteConfirmed", onRefresh as any);
    window.addEventListener("memebattles:txConfirmed", onRefresh as any);
    return () => {
      window.removeEventListener("memebattles:upvoteConfirmed", onRefresh as any);
      window.removeEventListener("memebattles:txConfirmed", onRefresh as any);
    };
  }, [activeChainId]);

  const sentinelRef = useRef<HTMLDivElement | null>(null);

  const baseParams = useMemo(() => {
    return {
      chainId: activeChainId,
      limit: 24,
      tab: query.tab ?? "trending",
      sort: query.sort ?? "default",
      status: query.status ?? "all",
      search: query.search ?? "",

      // Filters that require USD conversion.
      // We pass bnbUsd so the API can filter on marketcap_usd deterministically.
      bnbUsd: bnbUsd ? bnbUsd : null,
      mcapMinUsd: query.mcapMinUsd ?? null,
      mcapMaxUsd: query.mcapMaxUsd ?? null,
      progressMinPct: query.progressMinPct ?? null,
      progressMaxPct: query.progressMaxPct ?? null,
    };
  }, [activeChainId, query, bnbUsd]);

  // Reset + fetch first page whenever the query changes.
  useEffect(() => {
    let mounted = true;
    (async () => {
      setLoading(true);
      setErr(null);
      try {
        if (DEBUG) {
          console.debug('[CampaignGrid] fetch first page params', { ...baseParams, cursor: 0 });
        }
        const resp = await fetchCampaignFeed({ ...baseParams, cursor: 0, _r: refetchNonce });
        if (!mounted) return;
        if (DEBUG) {
          console.debug('[CampaignGrid] first page response', {
            count: resp.items?.length ?? 0,
            sample: (resp.items ?? []).slice(0, 3).map((x) => ({
              campaignAddress: x.campaignAddress,
              logoUri: x.logoUri,
              name: x.name,
              symbol: x.symbol,
            })),
          });
        }
        setItems(resp.items ?? []);
        setNextCursor(resp.nextCursor ?? null);
        setLastUpdatedAt(resp.updatedAt ?? null);
      } catch (e: any) {
        if (!mounted) return;
        setErr(e?.message ?? "Failed to load campaigns");
        setItems([]);
        setNextCursor(null);
      } finally {
        if (!mounted) return;
        setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [baseParams, refetchNonce]);

  // Hydrate missing token images from on-chain logoURI.
  // This keeps the DB feed fast for stats/sorts while matching the behavior of
  // pages that render images via useLaunchpad().fetchCampaigns().
  useEffect(() => {
    let cancelled = false;

    const missing = (items || [])
      .map((it) => String(it.campaignAddress ?? "").toLowerCase())
      .filter((addr) => addr && !logoCache[addr])
      .filter((addr) => {
        // If the feed already has a logo, don't hydrate.
        const found = (items || []).find((x) => String(x.campaignAddress ?? "").toLowerCase() === addr);
        return !found?.logoUri;
      })
      .slice(0, 24);

    if (!missing.length) return;

    if (DEBUG) {
      console.debug('[CampaignGrid] hydrating missing logos', {
        missingCount: missing.length,
        missing: missing.slice(0, 10),
      });
    }

    (async () => {
      try {
        const pairs = await Promise.all(
          missing.map(async (addr) => {
            const uri = await fetchCampaignLogoURI(addr);
            return [addr, uri] as const;
          })
        );
        if (cancelled) return;
        if (DEBUG) {
          console.debug('[CampaignGrid] hydration results', {
            resolved: pairs
              .filter(([, uri]) => !!uri)
              .slice(0, 10)
              .map(([addr, uri]) => ({ addr, uri, resolvedUrl: resolveImageUri(uri) })),
            unresolved: pairs.filter(([, uri]) => !uri).slice(0, 10).map(([addr]) => addr),
          });
        }
        setLogoCache((prev) => {
          const next = { ...prev };
          for (const [addr, uri] of pairs) {
            if (uri) next[addr] = uri;
          }
          return next;
        });
      } catch {
        if (DEBUG) console.debug('[CampaignGrid] hydration failed');
        // silent: missing images are non-fatal
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [items, logoCache, fetchCampaignLogoURI, DEBUG]);

  const loadMore = async () => {
    if (loadingMore || loading || nextCursor == null) return;
    setLoadingMore(true);
    try {
      if (DEBUG) {
        console.debug('[CampaignGrid] loadMore params', { ...baseParams, cursor: nextCursor });
      }
      const resp = await fetchCampaignFeed({ ...baseParams, cursor: nextCursor, _r: refetchNonce });
      if (DEBUG) {
        console.debug('[CampaignGrid] loadMore response', {
          count: resp.items?.length ?? 0,
          nextCursor: resp.nextCursor,
        });
      }
      setItems((prev) => [...prev, ...(resp.items ?? [])]);
      setNextCursor(resp.nextCursor ?? null);
      setLastUpdatedAt(resp.updatedAt ?? null);
    } catch (e: any) {
      setErr(e?.message ?? "Failed to load more");
    } finally {
      setLoadingMore(false);
    }
  };

  // Infinite scroll: load next page when sentinel becomes visible.
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) loadMore();
        }
      },
      { root: null, rootMargin: "600px", threshold: 0 }
    );
    obs.observe(el);
    return () => obs.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sentinelRef.current, nextCursor, loading, loadingMore, baseParams]);

  const vms: CampaignCardVM[] = useMemo(() => {
    const GRAD_TARGET_BNB = 50;

    const isTrendingDefault = baseParams.tab === "trending" && baseParams.sort === "default";
    const mapped = (items || []).map((it) => {
      const addr = String(it.campaignAddress ?? "").toLowerCase();
      const patch = patchByCampaign[addr];

      const mcapBnb = Number((patch?.marketcapBnb ?? it.marketcapBnb) ?? NaN);
      const mcapUsd = Number.isFinite(mcapBnb) && bnbUsd ? mcapBnb * bnbUsd : NaN;
      const marketCapUsdLabel = Number.isFinite(mcapUsd) ? formatCompactUsd(mcapUsd) : null;
      const rawLogo = it.logoUri || logoCache[addr] || null;

      let progressPct: number | null = it.progressPct ?? null;

      const activitySec = (patch?.lastActivityAt != null ? Number(patch.lastActivityAt) : safeUnixSeconds((it as any).lastActivityAt ?? null)) ?? 0;
      const raised = Number(patch?.raisedTotalBnb ?? NaN);
      if (Number.isFinite(raised)) {
        progressPct = Math.max(0, Math.min(100, (raised / GRAD_TARGET_BNB) * 100));
      }

      return {
        campaignAddress: addr,
        name: String(it.name ?? "Unknown"),
        symbol: String(it.symbol ?? ""),
        logoURI: resolveImageUri(rawLogo) ?? undefined,
        creator: it.creatorAddress ?? undefined,
        createdAt: safeUnixSeconds(it.createdAtChain ?? null) ?? undefined,
        lastActivityAtSec: activitySec,
        marketCapUsdLabel,
        athLabel: marketCapUsdLabel,
        progressPct,
        isDexTrading: Boolean(it.isDexTrading),
        votes24h: Number(patch?.votes24h ?? it.votes24h ?? 0),
      } as CampaignCardVM;
    });

    if (!isTrendingDefault) return mapped;

    return mapped.slice().sort((a: any, b: any) => {
      const aa = Number(a.lastActivityAtSec ?? 0);
      const bb = Number(b.lastActivityAtSec ?? 0);
      if (bb !== aa) return bb - aa;
      const ac = Number(a.createdAt ?? 0);
      const bc = Number(b.createdAt ?? 0);
      if (bc !== ac) return bc - ac;
      return String(a.campaignAddress).localeCompare(String(b.campaignAddress));
    });
  }, [items, bnbUsd, logoCache, patchByCampaign, baseParams]);

  const resultsMeta = useMemo(() => {
    const count = vms.length;
    const updated = lastUpdatedAt ? Math.floor((Date.now() - Date.parse(lastUpdatedAt)) / 1000) : null;
    const updatedLabel = updated != null && Number.isFinite(updated) ? `${Math.max(0, updated)}s ago` : "—";
    return `Showing ${count} campaigns • Updated ${updatedLabel}`;
  }, [vms.length, lastUpdatedAt]);

  return (
    <div className={cn("w-full", className)}>
      <div className="mb-3 flex items-center justify-between gap-4">
        <div className="text-xs text-muted-foreground">{resultsMeta}</div>
      </div>

      {loading && !vms.length ? (
        <div className="grid grid-cols-[repeat(auto-fit,minmax(180px,1fr))] gap-4 justify-items-center">
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className="aspect-[1/2] w-full max-w-[clamp(160px,20vw,210px)] rounded-2xl border border-border/40 bg-card/40 animate-pulse"
            />
          ))}
        </div>
      ) : err ? (
        <div className="py-10 text-center text-sm text-muted-foreground">{err}</div>
      ) : vms.length === 0 ? (
        <div className="py-10 text-center text-sm text-muted-foreground">No campaigns yet.</div>
      ) : (
        <>
          <div className="grid grid-cols-[repeat(auto-fit,minmax(180px,1fr))] gap-4 justify-items-center">
            {vms.map((vm) => (
              <CampaignCard key={vm.campaignAddress} vm={vm} chainIdForStorage={activeChainId} />
            ))}
          </div>

          <div ref={sentinelRef} className="h-12" />

          {loadingMore ? (
            <div className="py-6 text-center text-xs text-muted-foreground">Loading more…</div>
          ) : nextCursor == null ? (
            <div className="py-6 text-center text-xs text-muted-foreground">End of results</div>
          ) : null}
        </>
      )}
    </div>
  );
}
