import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase env vars (VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY)');
}

const supabase = createClient(supabaseUrl, supabaseAnonKey);

export async function followUser(followingId: string): Promise<void> {
  const { error } = await supabase
    .from('user_follows')
    .insert({ following_id: followingId.toLowerCase() });
  if (error) throw error;
}

export async function unfollowUser(followingId: string): Promise<void> {
  const { error } = await supabase
    .from('user_follows')
    .delete()
    .eq('following_id', followingId.toLowerCase());
  if (error) throw error;
}

export async function isFollowingUser(followingId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('user_follows')
    .select('id')
    .eq('following_id', followingId.toLowerCase())
    .maybeSingle();
  if (error && error.code !== 'PGRST116') throw error;
  return !!data;
}

export async function getFollowersCount(userId: string): Promise<number> {
  const { count, error } = await supabase
    .from('user_follows')
    .select('*', { count: 'exact', head: true })
    .eq('following_id', userId.toLowerCase());
  if (error) throw error;
  return count ?? 0;
}

export async function getFollowingCount(userId: string): Promise<number> {
  const { count, error } = await supabase
    .from('user_follows')
    .select('*', { count: 'exact', head: true })
    .eq('follower_id', userId.toLowerCase());
  if (error) throw error;
  return count ?? 0;
}

export async function getFollowers(userId: string) {
  const { data, error } = await supabase
    .from('user_follows')
    .select('follower_id, profiles!inner(*)')
    .eq('following_id', userId.toLowerCase());
  if (error) throw error;
  return (data || []).map(d => ({ id: d.follower_id, profile: d.profiles }));
}

export async function getFollowing(userId: string) {
  const { data, error } = await supabase
    .from('user_follows')
    .select('following_id, profiles!inner(*)')
    .eq('follower_id', userId.toLowerCase());
  if (error) throw error;
  return (data || []).map(d => ({ id: d.following_id, profile: d.profiles }));
}

// Campaign follows
export async function followCampaign(campaignAddress: string): Promise<void> {
  const { error } = await supabase
    .from('campaign_follows')
    .insert({ campaign_address: campaignAddress.toLowerCase() });
  if (error) throw error;
}

export async function unfollowCampaign(campaignAddress: string): Promise<void> {
  const { error } = await supabase
    .from('campaign_follows')
    .delete()
    .eq('campaign_address', campaignAddress.toLowerCase());
  if (error) throw error;
}

export async function isFollowingCampaign(campaignAddress: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('campaign_follows')
    .select('id')
    .eq('campaign_address', campaignAddress.toLowerCase())
    .maybeSingle();
  if (error && error.code !== 'PGRST116') throw error;
  return !!data;
}

export async function getFollowedCampaigns(userId: string): Promise<string[]> {
  const { data, error } = await supabase
    .from('campaign_follows')
    .select('campaign_address')
    .eq('user_id', userId.toLowerCase());
  if (error) throw error;
  return (data || []).map(d => d.campaign_address);
}