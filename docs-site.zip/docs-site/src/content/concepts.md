---
title: Concepts (Moved)
description: This page moved. Use Core Concepts.
---

This page has been replaced by **[Core Concepts](/core-concepts)**.

Why: Core Concepts is now a structured section with individual pages for campaigns, bonding curves, graduation, UpVotes, leagues, fees, and claims.
