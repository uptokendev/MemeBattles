---
title: Finalize fee
description: Fee charged on graduation/finalization.
---

## Overview
Placeholder page.
