export const siteConfig = {
  title: 'MemeBattles Docs',
  mainSiteUrl: 'https://memebattles.gg'
}
