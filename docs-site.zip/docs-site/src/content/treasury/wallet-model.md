---
title: Wallet model (Owners/Ops)
description: Owners Safe + Ops Safe structure.
---

## Overview
Placeholder page.
