---
title: Weekly distribution policy
description: Ops normalization → retention → founder payouts.
---

## Overview
Placeholder page.
