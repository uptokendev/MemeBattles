---
title: Launch lifecycle
description: From launch → bonding curve → graduation.
---

## Overview
This page is a placeholder.

Add the final lifecycle explanation here.
