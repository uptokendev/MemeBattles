---
title: Bonding curve
description: How buys/sells move price before graduation.
---

## Overview
Placeholder page.
