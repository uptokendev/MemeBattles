---
title: Graduation
description: What happens when a campaign reaches the graduation threshold.
---

## Overview
Placeholder page.
