---
title: Weekly & monthly epochs
description: How league prize pools and epochs work.
---

## Overview
Placeholder page.
