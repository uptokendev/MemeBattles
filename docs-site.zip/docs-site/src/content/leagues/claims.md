---
title: Claims
description: How winners claim league rewards.
---

## Overview
Placeholder page.
